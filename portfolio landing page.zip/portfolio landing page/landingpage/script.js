// Toggle Menu Visibility
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('show');
  }
  
  // Search Functionality
  function search() {
    const query = document.getElementById('search-bar').value.trim();
    if (query) {
      alert(`You searched for: ${query}`);
    } else {
      alert('Please enter a search term.');
    }
  }
  